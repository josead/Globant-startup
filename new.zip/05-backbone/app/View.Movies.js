define(['backbone','app/Model.Movie'],
	function (Backbone, Movie) {

		return Backbone.View.extend({
			tagName: 'div',

			className: 'moviesLibrary',

			initialize: function() {
 				//this.listenTo(this.model, 'add', this.addOne);
			},

			render: function () {
				this.collection.each(this.addOne, this);
			},

			addOne: function (movie) {
				console.log(movie);
				var movieView = new Movie({ model: movie});
				this.$el.append(movieView.render().el)
			}

		});

});